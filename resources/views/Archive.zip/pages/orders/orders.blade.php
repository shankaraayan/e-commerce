@extends('../Layout.Layout')

@section("content")
<h2>ordrs list</h2>
@endsection