<header>
    <div class="web_header_top">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 col-7">
                    <a href="#"> About Us </a>
                    <span class="text-muted px-2">|</span> <a href="#">
                        Contact Us</a>
                </div>
                <div class="col-sm-8 col-5 text-end">
                    <a href="#">
                        <i class="fa fa-phone"></i>
                        <span class="d-none d-sm-inline"> +91-9414858800 </span>
                    </a>
                   
                    <span class="text-muted px-2">|</span> 
                    <a href="{{route('user.orders')}}">
                        <i class="fa fa-truck"></i>
                        <span class="d-none d-sm-inline"> Track Order </span>
                    </a>
                    
                    <span class="text-muted px-2">|</span> <a href="javascript:void(0)" onclick="loginclick();" data-bs-toggle="modal" data-bs-target="#loginPopup">
                         @auth
                            <a href="/logout">
                                <i class="fa fa-sign-out"></i>
                                <span class="d-none d-sm-inline">Logout</span>
                            </a>
                        @else
                            <a href="javascript:void(0)" onclick="loginclick();" onclick="loginclick();" data-bs-toggle="modal" data-bs-target="#loginPopup">
                                <i class="fa fa-sign-in"></i>
                                <span class="d-none d-sm-inline">Login</span>
                            </a>
                        @endauth
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="web_logo_section py-2">
        <div class="container">
            <div class="row d-flex align-items-center justify-content-between">
                <div class="col-lg-3 col-md-4 col-4 order-1">
                    <a href="{{ url('/') }}">
                        <img src="https://i0.wp.com/campergold.net/wp-content/uploads/2023/02/CG_logo_white.png" alt="CamperGold" style="max-width: 150px;">
                    </a>
                </div>
                <div class="col-lg-6 col-md-6 order-md-2 order-4 mb-3 mb-md-0 d-xl-block d-lg-block d-md-none d-none">
                     <form action="#">
                                <div class="input-group">
                                    <input value="" type="text" class="form-control" id="keyword" name="keyword" placeholder="Search products and more" aria-label="Search products and more" aria-describedby="button-addon2">
                                    <button class="btn btn_primary" type="submit" id="button-addon2">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </div>
                                <div id="search-results-dropdown"  style="display: none; width:40%;" class="dropdown-menu">
                                    <div class="dropdown-content">
                                        <ul id="suggestion-list"></ul>
                                    </div>
                                </div>
                                    <!--<div id="search-results-dropdown" style="display: none;"></div>-->
                            </form>
                </div>
                <div class="col-lg-3 col-md-2 col-8 order-3 search_bar_icons d-flex justify-content-end">
                    <div class=" mx-2 mx-lg-3 d-none d-lg-block">
                        <a class="d-flex flex-column align-items-center" href="{{route('shop')}}">
                            <i class="fa fa-shopping-bag"></i>
                            <div class="label_">Shop</div>
                        </a>
                    </div>
                    <div class="mx-2 mx-lg-3 d-none d-lg-block">
                        @auth
                          <a class="d-flex flex-column align-items-center" href="{{route('user.dashboard')}}">
                                <i class="fa fa-user"></i>
                                <div class="label_">{{ Auth::user()->firstname }}</div>
                            </a>
                        @else
                            <a class="d-flex flex-column align-items-center" id="login_button" href="javascript:void(0)" onclick="loginclick();" data-bs-toggle="modal" data-bs-target="#loginPopup">
                                <i class="fa fa-user"></i>
                                <div class="label_">Profile</div>
                            </a>
                        @endauth
                    </div>
                    <div class="mx-3 mx-lg-3">
                        <a class="d-flex flex-column align-items-center" href="#">
                            <i class="fa fa-heart"></i>
                            <div class="label_">Wishlist</div>
                        </a>
                    </div>
                    <div class="d-flex flex-column align-items-center position-relative" id="cart_section">
                        <a class="d-flex flex-column align-items-center" href="{{ url('cart') }}">
                            <i class="fa fa-shopping-cart"></i>
                            <div class="label_">Cart <span class="my_cart_count">{{ count((array) session('cart')) }}</span></div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="web_mainmenu py-2">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <ul class="d-block d-lg-none shop_mega_menu d-flex justify-content-between">
                        <li class="h4" id="toggle_main_menu_"> <i class="px-3 pt-2 fa fa-bars"></i> </li>
                        <li class="d-xl-none d-lg-none d-md-block d-block w-75">
                            <form action="#">
                                <div class="input-group">
                                    <input value="" type="text" class="form-control" id="keyword" name="keyword" placeholder="Search products and more" aria-label="Search products and more" aria-describedby="button-addon2">
                                    <button class="btn btn_primary" type="submit" id="button-addon2">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </div>
                            </form>
                        </li>
                    </ul>
                    <ul id="main_menu_" class="d-none d-block d-lg-flex mobile_menu shop_mega_menu justify-content-between">
                          <li class="active"> <a href="{{ url('/') }}">Home</a> </li>
                        <li class=""> <a href="{{route('shop')}}"> Shop </a> </li>
                        @foreach(headerCategories() as $cat)
                        <li class=""> <a href="{{route('shop',$cat->slug)}}"> {{$cat->name}} </a> </li>
                        @endforeach
                        {{-- <li class=""> <a href="#"> Solar Komplettsysteme </a> </li>
                        <li class=""> <a href="#"> Hybrid Solarkomplettset </a> </li>
                        <li class=""> <a href="#"> Solarmodule </a> </li>
                        <li class=""> <a href="#"> Easy Peak Power </a> </li> --}}
                        {{-- <li class=""> <a href="#"> Blog </a> </li> --}}
                        <li class=""> <a href="#"> Contact Us </a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('#toggle_main_menu_').click(function() {
            $('#main_menu_').toggleClass("d-none");
        });
    </script>
    @include('includes.login')
    <!-- Checkout & Cart Offcanvas -->
    @include('includes.cart')
    <!-- Checkout & Cart Offcanvas -->
    @include('includes.toast')
             
</header>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $("#loginForm").on('submit', function(e) {
            e.preventDefault();
            console.log(this);
        });
    })
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    $('#keyword').keyup(function() {
        var keyword = $(this).val();

        if (keyword.length >= 2) {
            $.ajax({
                url: '{{route('search')}}',
                method: 'GET',
                data: { keyword: keyword },
                success: function(response) {
                    var dropdown = $('#search-results-dropdown');
                    dropdown.empty();

                    if (response.length > 0) {
                        response.map(function(item) {
                            let url = "{{ route('product.detail') }}/" + item.slug;
                        
                            let imageUrl = "{{ asset('root/public/uploads/') }}/" + item.thumb_image;
                            console.log(url);
                            dropdown.append('<a class="dropdown-item" href="' + url + '"> <img src="' + imageUrl + '" alt="Product Image" class="dropdown-item-image" style="width: 50px; height: 50px;"> ' + item.product_name + ' </a>');
                        });
                    } else {
                        dropdown.append('<a class="dropdown-item" href="#">No results found</a>');
                    }

                    dropdown.show();
                }
            });
        } else {
            $('#search-results-dropdown').empty().hide();
        }
    });
});





</script>