@extends('Layout.Layout')
@section("title")
Contact us
@endsection
@section("content")
    <h2>contact us</h2>
@endsection