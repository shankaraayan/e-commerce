@extends("../Layout.Layout")

@section("content")
    <h2>Single order</h2>
@endsection