@extends('user.layout')
@section('dasboard_content')
<div class="address_section g-0 px-0">
                <div class="dash_title text-uppercase border-bottom pb-3 mb-4 h6 d-xl-flex d-lg-flex d-md-flex d-block justify-content-between">
                  <div>Addresses</div>
                  <div class="p text-muted text-capitalize fw-normal fst-italic mt-xl-0 mt-lg-0 mt-md-0 mt-2"> The following addresses are used by default on the checkout page. </div>
                </div>
                <div class="container">
                  <div class="row row-cols-xl-2 row-cols-lg-2 row-cols-md-2 row-cols-1">
                    <div class="billing_add_section">
                      <h5 class="position-relative"> Billing Address <a data-bs-toggle="collapse" href="#edit_billing_add" role="button" aria-expanded="false" aria-controls="edit_billing_add">
                          <i class="bi bi-pencil ci_blue"></i>
                        </a>
                      </h5> @if(!@empty($address['billing_address'])) <p class="fst-italic">{{$address["billing_address"]['fullname']}}</p>
                      <div class="small text-muted">
                        <span class="user_mob">{{$address["billing_address"]['phone']}}</span>
                        <br />
                        <span class="user_email">{{$address["billing_address"]['email']}}</span>
                        <br />
                        <!-- <span class="user_add_aprtmnt">, </span>
                        <br /> -->
                        <span class="user_add_street"> {{$address["billing_address"]['street']}}, </span>
                        <br />
                        <span class="user_zip_code">{{$address["billing_address"]['pincode']}}, </span>
                        <span class="user_add_city">Jaipur.</span>
                        <br />
                        <span class="user_country">{{$address["billing_address"]['country']}}</span>
                      </div> @else <p class="fst-italic text-muted no_address">You have not yet created an address of this type.</p> @endif
                    </div>
                    <div class="delivery_add_section">
                      <h5 class="position-relative"> Delivery Address <a data-bs-toggle="collapse" href="#edit_delivery_add" role="button" aria-expanded="false" aria-controls="edit_delivery_add">
                          <i class="bi bi-pencil ci_blue"></i>
                        </a>
                      </h5> @if(!@empty($address['shipping_address'])) <p class="fst-italic">{{$address["shipping_address"]['fullname']}}</p>
                      <div class="small text-muted">
                        <span class="user_mob">{{$address["shipping_address"]['phone']}}</span>
                        <br />
                        <span class="user_email">{{$address["shipping_address"]['email']}}</span>
                        <!-- <br />
                        <span class="user_add_aprtmnt">, </span> -->
                        <br />
                        <span class="user_add_street"> {{$address["shipping_address"]['street']}}, </span>
                        <br />
                        <span class="user_zip_code">{{$address["shipping_address"]['pincode']}}, </span>
                        <span class="user_add_city">Jaipur.</span>
                        <br />
                        <span class="user_country">{{$address["shipping_address"]['country']}}</span>
                      </div> @else <p class="fst-italic text-muted no_address">You have not yet created an address of this type.</p> @endif
                    </div>
                  </div>
                </div>
                <div class="collapse" id="edit_billing_add">
                  <div class="billing_add_update mt-3">
                    <div class="dash_title text-uppercase border-bottom pb-3 mb-4 h6"> Billing Address </div>
                    <form method="post" action="{{url('add_address',Auth::user()->id)}}"> @csrf <input type="text" name="address_type" value="billing" hidden />
                      <div class="row row-cols-1">
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['billing_address']['fullname']) ? $address['billing_address']['fullname'] : '' }}" name="fullname" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Rahul Kumawat" />
                            <label class="text-muted p" for="floatingInput">Name <sup class="text-danger">*</sup>
                            </label> @error('fullname') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                      </div>
                      <div class="row row-cols-xl-2 row-cols-lg-2 row-cols-md-1 row-cols-1">
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['billing_address']['phone']) ? $address['billing_address']['phone'] : '' }}" type="number" name="phone" class="form-control shadow-none" id="floatingInput" placeholder="Phone" />
                            <label class="text-muted p" for="floatingInput">Phone <sup class="text-danger">*</sup>
                            </label> @error('phone') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['billing_address']['email']) ? $address['billing_address']['email'] : '' }}" type="email" name="email" class="form-control shadow-none" id="floatingInput" placeholder="Last name" />
                            <label class="text-muted p" for="floatingInput">E-mail <sup class="text-danger">*</sup>
                            </label> @error('email') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-12">
                          <select name="country" class="form-select shadow-none mb-3" aria-label="counrty-select">
                            <option value="">Select country/Region... </option>
                            @if(!empty($address['billing_address']['country']))
                                <option value="{{$address['billing_address']['country']}}" selected>Select country/Region... </option>
                            @endif
                            <option value="AT">Austria</option>
                            <option value="GR">Germany</option>
                          </select> @error('country') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['billing_address']['street']) ? $address['billing_address']['street'] : '' }}" name="street" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Street" />
                            <label class="text-muted p" for="floatingInput">Street <sup class="text-danger">*</sup>
                            </label> @error('street') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['billing_address']['apartment']) ? $address['billing_address']['apartment'] : '' }}"" name="apartment" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Apartment" />
                            <label class="text-muted p" for="floatingInput">Apartment <sup class="text-danger">*</sup>
                            </label> @error('apartment') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['billing_address']['city']) ? $address['billing_address']['city'] : '' }}" name="city" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Place-city" />
                            <label class="text-muted p" for="floatingInput">Place/City <sup class="text-danger">*</sup>
                            </label> @error('city') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['billing_address']['pincode']) ? $address['billing_address']['pincode'] : '' }}" type="number" name="pincode" class="form-control shadow-none" id="floatingInput" placeholder="Zip code" />
                            <label class="text-muted p" for="floatingInput">Zip code <sup class="text-danger">*</sup>
                            </label> @error('pincode') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                      </div>
                      <div class="address_btns">
                        <button type="submit" class="btn btn_primary">Save Address</button>
                        <button type="button" class="btn btn_outline_secondary">Cancel</button>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="collapse" id="edit_delivery_add">
                  <div class="billing_add_update mt-3">
                    <div class="dash_title text-uppercase border-bottom pb-3 mb-4 h6"> Delivery Address </div>
                    <form method="post" action="{{url('add_address',Auth::user()->id)}}"> @csrf <input type="text" name="address_type" value="delivery" hidden />
                      <div class="row row-cols-1">
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{!empty($address['shipping_address']['fullname']) ? $address['shipping_address']['fullname'] : '' }}" name="fullname" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Rahul Kumawat" />
                            <label class="text-muted p" for="floatingInput">Name <sup class="text-danger">*</sup>
                            </label> @error('fullname') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                      </div>
                      <div class="row row-cols-xl-2 row-cols-lg-2 row-cols-md-1 row-cols-1">
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{ !empty($address['shipping_address']['phone']) ? $address['shipping_address']['phone'] : '' }}" type="number" name="phone" class="form-control shadow-none" id="floatingInput" placeholder="Phone" />
                            <label class="text-muted p" for="floatingInput">Phone <sup class="text-danger">*</sup>
                            </label> @error('phone') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{ !empty($address['shipping_address']['email']) ? $address['shipping_address']['email'] : '' }}" type="email" name="email" class="form-control shadow-none" id="floatingInput" placeholder="Last name" />
                            <label class="text-muted p" for="floatingInput">E-mail <sup class="text-danger">*</sup>
                            </label> @error('email') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-12">
                          <select name="country" class="form-select shadow-none mb-3" aria-label="counrty-select">
                            <option value="">Select country/Region... </option>
                            @if(!empty($address['shipping_address']['country']))
                            <option value="{{$address['shipping_address']['country']}}" selected>Austria</option>
                            @endif
                
                            <option value="GR">Germany</option>
                          </select> @error('country') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                        <div class="col">
                          <div class="form-floating mb-3">
                            <input value="{{ !empty($address['shipping_address']['street']) ? $address['shipping_address']['street'] : '' }}" name="street" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Street" />
                            <label class="text-muted p" for="floatingInput">Street <sup class="text-danger">*</sup>
                            </label> @error('street') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                          <div class="form-floating mb-3">
                            <input name="apartment" value="{{ !empty($address['shipping_address']['apartment']) ? $address['shipping_address']['apartment'] : '' }}" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Apartment" />
                            <label class="text-muted p" for="floatingInput">Apartment <sup class="text-danger">*</sup>
                            </label> @error('apartment') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                          <div class="form-floating mb-3">
                            <input value="{{ !empty($address['shipping_address']['city']) ? $address['shipping_address']['city'] : '' }}" name="city" type="text" class="form-control shadow-none" id="floatingInput" placeholder="Place-city" />
                            <label class="text-muted p" for="floatingInput">Place/City <sup class="text-danger">*</sup>
                            </label> @error('city') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                          <div class="form-floating mb-3">
                            <input value="{{ !empty($address['shipping_address']['pincode']) ? $address['shipping_address']['pincode'] : '' }}" type="number" name="pincode" class="form-control shadow-none" id="floatingInput" placeholder="Zip code" />
                            <label class="text-muted p" for="floatingInput">Zip code <sup class="text-danger">*</sup>
                            </label> @error('pincode') <span class="text-danger">{{ $message }}</span> @enderror
                          </div>
                        </div>
                      </div>
                      <div class="address_btns">
                        <button type="submit" class="btn btn_primary">Save Address</button>
                        <button type="button" class="btn btn_outline_secondary">Cancel</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>


<script>
    const billing_address = document.getElementById("edit_billing_add");
    const delivery_address = document.getElementById("edit_delivery_add");

    billing_address.addEventListener("show.bs.collapse", function () {
        if (delivery_address.classList.contains("show")) {
            delivery_address.classList.remove("show");
        }
    });

    delivery_address.addEventListener("show.bs.collapse", function () {
        if (billing_address.classList.contains("show")) {
            billing_address.classList.remove("show");
        }
    });
</script>
@endsection
