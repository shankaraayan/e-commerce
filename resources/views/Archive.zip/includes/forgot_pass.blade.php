<div id="forgot_pass_sec" class="modal-body" style="display: none;">
    <div class="mb-4">
        <h1 class="modal-title fs-5 mb-1" id="loginPopupModalLabel">Forgot Password?</h1>
        <p class="mb-0">Reset your password by entering your mobile number or email id</p>
    </div>
    <form id="forgotForm">
        @csrf
        <div class="mb-3">
            <label for="loginEmail" class="form-label">Email</label>
            <input type="email" class="form-control input" name="email" placeholder="enter your email" id="forgetEmail" aria-describedby="emailHelp" />
        </div>

        <button type="submit" class="btn btn_primary w-100">GET OTP</button>
    </form>

    <div class="modal-footer justify-content-end">
        <p class="fs-6">
            Continue to <span><a onclick="showforgotpass();" href="javascript:void(0)" class="ci_green ms-1">Sign in</a></span>
        </p>
    </div>
</div>
