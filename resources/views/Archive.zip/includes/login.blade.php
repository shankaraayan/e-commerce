<!-- Login Modal Popup -->
<div class="modal fade" id="loginPopup" tabindex="-1" aria-labelledby="loginPopupModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header align-items-start">
                <h1 class="modal-title fs-5 mb-1" id="loginPopupModalLabel">Login</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <!----------- Login ---------->
            <div id="login_sec" class="modal-body" style="display: block;">
                <div class="mb-4">
                    <p class="mb-0">Track your order, create wishlist & more</p>
                </div>
                <form method="post" action="{{url('login')}}">
                   @csrf
                    <div class="mb-3">
                        <label for="loginEmail" class="form-label">Email</label>
                        <input type="email" value="prabhat1323@gmail.com" class="form-control input" placeholder="enter your email" id="loginEmail" name="email" />
                        @error('email')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div class="mb-3">
                        <label for="loginPassword" class="form-label" >Password</label>
                        <input type="password" value="Prabhat@7808" class="form-control input" placeholder="enter your Password" id="loginPassword" name="password" />
                        @error('password')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                    </div>
               
                    <button id="submit_btn" type="submit" class="btn btn_primary w-100 mb-3">Login</button>
                    <div id="message"></div>
                </form>
                <div class="justify-content-end d-flex justify-content-between mt-4 mb-2">
                    <a onclick="showforgotpass();" href="javascript:void(0)">Forgot password?</a>
                    <p class="fs-6 mb-0">
                        New at CamperGold? <span><a href="{{url('/register')}}" class="ci_green ms-1">Register here</a></span>
                    </p>
                </div>
            </div>
            <!----------- Login ---------->
         
            <!----------- Forgot Password ---------->
            @include('includes.forgot_pass')
            <!----------- Forgot Password ---------->
        </div>
    </div>
</div>
<!-- Login Modal Popup -->

@if(Session::get('login_error'))

    <script>
        var login = document.getElementById('login_button');
        login.click();
    </script>
@endif