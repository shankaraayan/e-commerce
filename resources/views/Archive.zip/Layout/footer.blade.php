 <!--------------- Footer Start ------------------------->
 <footer>
                <section class="main-footer mt-5">
                    <div style="background: linear-gradient(0deg, #0000009e, #37517e),url(https://campergold.net/wp-content/uploads/2021/08/carado_wohnmobil_kaufen_campervan_baureihe_2.jpg); background-size: cover; background-attachment: fixed;"
                        class="pt-lg-5 py-1 text-white footer-inner-sec">
                        <div class="container py-lg-5 py-1">
                            <div class="row footer-inner-sec">
                                <div class="col-md-6 col-xs-12 pb-5">
                                    <div class="footer-info">
                                        <div class="col-12">
                                            <img class="img-fluid" style="max-width: 150px;"
                                                src="https://i0.wp.com/campergold.net/wp-content/uploads/2023/02/CG_logo_white.png"
                                                alt="CamperGold">
                                        </div>
                                        <div class="pt-4">
                                            <div class="footer-text text-white">
                                                <p>Bei uns erleben Sie die Camping Welt!
                                                    Bei CamperGold.net werden Sie alles finden, was Ihr Campingherz
                                                    begehrt:
                                                    Wir verstehen uns als Innovations&amp; Inspirationspartner mit
                                                    wertvollen Tipps &amp; Produkten für Ihren Campingurlaub. Zusätzlich
                                                    bietet CamperGold Ihnen über die Webseite www.campergold.com ein
                                                    vollumfängliches&nbsp;<a class="link-color" href="#" target="_blank"
                                                        rel="noopener">Mietportal</a>&nbsp;zum vermieten und mieten von
                                                    ihrem mobilen Zuhause. Wenn Sie keinen eigenen Camper nutzen, aber
                                                    dennoch vom Campingmarkt profitieren möchten, bietet Ihnen
                                                    die&nbsp;<a class="link-color" href="#" target="_blank"
                                                        rel="noopener">www.campergold.de</a>&nbsp;Plattform den idealen
                                                    Einstieg in die Verdienstmöglichkeit der Campingwelt. Wir freuen uns
                                                    auf
                                                    Sie…
                                                </p>
                                            </div>
                                            <p class="pt-4">
                                                <a class="text-white footer-text footer-text footer-text footer-text"
                                                    target="_blank" href="https://campergold.net/">Online-Shop</a>
                                                <a class="text-white footer-text footer-text footer-text"
                                                    href="https://campergold.com/" target="_blank"
                                                    rel="noopener">Online-Camper-Buchung</a>
                                                <a class="text-white footer-text footer-text"
                                                    href="https://campergold.de" target="_blank" rel="noopener"> Händler
                                                    Shop</a>
                                                <a class="text-white footer-text" href="https://covid-test-bramsche.de/"
                                                    target="_blank" rel="noopener">Covid Test Bramsche</a>
                                            </p>
                                        </div>
                                        <hr style=" border: 1px solid white;">
                                        <img class="img-fluid pb-3"
                                            src="https://campergold.de/frontend/assets/paypal-plus-logo-p6reqcckrq9vz2hup9uo8cw42gewnawmxylsyq0w62.png"
                                            alt="">
                                        <!-- <hr style=" border: 1px solid white;"> -->
                                    </div>
                                    <!--<div class="footer_add mt-3">-->
                                    <!--    <div class="row row-cols-lg-3 row-cols-xl-3 row-cols-md-2 row-cols-2">-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Frankfurt-->
                                    <!--                </h5>-->
                                    <!--                <p class="text-white">Ground floor, Bethmannstrasse 8,<br>-->
                                    <!--                    Frankfurt, 60311</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Köln-->
                                    <!--                </h5>-->
                                    <!--                <p class="text-white">Neumarkt Galerie, Richmodstrasse 6,<br>-->
                                    <!--                    Cologne, Nordrhein-Westfalen<br> 50667</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Stuttgart-->
                                    <!--                </h5>-->
                                    <!--                <p class="text-white">Friedrichstrasse 15, Stuttgart,<br>-->
                                    <!--                    Baden-Württemberg 70174</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Bayern-->
                                    <!--                </h5>-->
                                    <!--                <p class="text-white">Josephspitalstraße 15, Munich,<br> Bayern-->
                                    <!--                    80331</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Dresden-->
                                    <!--                </h5>-->
                                    <!--                <p class="text-white">3rd and 4th floor,<br> Altmarkt 10 B/D,<br>-->
                                    <!--                    Dresden, 01067</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Berlin-->
                                    <!--                </h5>-->
                                    <!--                <p class="text-white">5th floor, Haus 2,<br> Potsdamer Platz 10,-->
                                    <!--                    Berlin,<br> Berlin 10785</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Osnabrück-->
                                    <!--                </h5>-->
                                    <!--                <p class="text-white">Pagenstecherstraße 56 49090<br> Osnabrück-->
                                    <!--                    Deutschland</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--        <div class="col">-->
                                    <!--            <div class="text-left">-->
                                                    <!-- <h5><span><i class="bi bi-geo-alt bounce fs-5 me-1"></i></span>Bünde</h5> -->
                                    <!--                <h5><span><i class="fa fa-map-marker bounce fs-5 me-1"-->
                                    <!--                            aria-hidden="true"></i></span>Bünde</h5>-->
                                    <!--                <p class="text-white">Rödinghauser Straße<br> 124 32257 Bünde</p>-->
                                    <!--            </div>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <div class="important-links">
                                        <div>
                                            <h5 class="text-white">SCHNELLE LINKS</h5>
                                        </div>
                                        <ul class="p-0">
                                            <li class=" list-inline">
                                                <ul class="sub-sub-menu list-inline">
                                                    <li class="pb-2 pt-4"><a href="#"><span
                                                                class="footer-text">Home</span></a></li>
                                                    <li class="pb-2"><a href="#"><span
                                                                class="footer-text">Über</span></a></li>
                                                    <li class="pb-2"><a href="#"><span
                                                                class="footer-text">Produkte</span></a></li>
                                                    <li class="pb-2"><a href="#"><span
                                                                class="footer-text">Impressum</span></a></li>
                                                    <li class="pb-2"><a href="#"><span
                                                                class="footer-text">AGB</span></a></li>
                                                    <li class="pb-2"><a href="#"><span
                                                                class="footer-text">Datenschutzerklärung</span></a></li>
                                                    <li class="pb-2"><a href="https://campergold.de/contact"><span
                                                                class="footer-text">Kontaktieren uns</span></a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <div class="footer-contact">
                                        <div>
                                            <h5 class="text-white">KONTAKT INFORMATION</h5>
                                        </div>
                                        <div class="pt-4 footer-text">
                                            <p><strong>Adresse :</strong><br>CamperGold GmbH<br>Neuer Wall 50<br>20354
                                                Hamburg</p>
                                            <p>Übergabestation Wohnmobile<br>CamperGold GmbH<br>Billbrookdeich
                                                184<br>22113 Hamburg</p>
                                            <p>Handelsregister: HRB 167609<br>Registergericht: Amtsgericht Hamburg</p>
                                            <p><strong>Zentrallager Deutschland</strong><br>CamperGold GmbH<br>Herr
                                                Patrick Willemer<br>Pagenstecherstraße 56,<br> 49090 Osnabrück,<br>
                                                Deutschland</p>
                                            <p><b>Vertreten durch Geschäftsführer<br></b>Patrick Willemer</p>
                                            <p>Umsatzsteuer-ID: DE 340 890 139</p>
                                            <p><strong>Hotline:</strong><br><a class="text-white"
                                                    href="tel:+49 (0)40 3346708 90">+49 (0)40 3346708
                                                    90</a><br><small>(Montag Bis Freitag : <br>10:00 - 12:30 &amp; 14:00
                                                    - 17:00)</small></p>
                                            <p><strong class="text-white">E-Mail:</strong><br><a class="text-white"
                                                    href="mailto:support@campergold.com">support@campergold.com</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="container">
                            <p class="footer-text" style="text-align: center;">© 2023 ERSTELLT VON STEGPEARL.CamperGold
                            </p>
                        </div>
                    </div>
                </section>
            </footer>