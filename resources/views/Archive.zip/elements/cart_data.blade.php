<div class="row g-3 mt-3">
    <!-- cart -->
    <div class="col-lg-9">
        <div class="card shadow">
            <div class="p-3">
                <h4 class="card-title pb-3 border-bottom">Your shopping cart</h4>
                <div class="d-xl-flex d-none row py-2 border-bottom align-items-center justify-content-center g-2">
                    <div class="col-xl-5 product">
                        <h6 class="p">Product</h6>
                    </div>
                    <div class="col-xl-2 cart_net_priceproduct text-center">
                        <h6 class="p">Net Price</h6>
                    </div>
                    <div class="col-xl-2 cart_net_productqty text-center">
                        <h6 class="p">Quantity</h6>
                    </div>
                    <div class="col-xl-2 cart_net_productsubtotal text-center">
                        <h6 class="p">Sub Total</h6>
                    </div>
                    <div class="col-xl-1 cart_net_productremove text-end">
                        <h6 class="p">Remove</h6>
                    </div>
                </div>
                <!-- Product with variations -->

                <!-- <div class="row gy-3 py-3 border-bottom">
                            <div class="col-xl-5 col-lg-6 col-md-12 col-12">
                                <div class="d-flex">
                                    <a href="#">
                                        <img src="https://i0.wp.com/campergold.net/wp-content/uploads/2023/04/fetaure1681722193-390-full-non-verbal19.jpg"
                                            class="border rounded me-2" style="width: 80px; height: 80px;">
                                    </a>
                                    <div class="">
                                        <a href="#" class="d-block p">Solar</a>
                                        <strong class="small">Estimated Ship Date May 18,
                                            2023</strong>
                                        <div class="cart_variation_dtls">
                                            <ul class="list-inline small text-muted mt-1">
                                                <li>Solar modules: 620</li>
                                                <li>Inverters: 600</li>
                                                <li>Cables: 5 meters + wieland plug</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="col-xl-2 col-lg-2 col-md-3 col-4 text-center d-flex align-items-center justify-content-center">
                                <div class="me-2">
                                    <text class="h6 fw-400 ci_green">$ 212</text>
                                </div>
                            </div>
                            <div
                                class="col-xl-2 col-lg-2 col-md-3 col-4 d-flex align-items-center justify-content-center">
                                <div class="addmore_qty d-flex align-items-center justify-content-center">
                                    <input type="button" value="-" class="minus btn_primary btn">
                                    <input type="number" id="" class="input-text cart_qty mx-1" step="1" min="0" max=""
                                        name="" value="1" size="4" placeholder="" inputmode="numeric">
                                    <input type="button" value="+" class="plus btn_primary btn">
                                </div>
                            </div>
                            <div
                                class="col-xl-2 col-lg-2 col-md-3 col-4 text-center d-flex align-items-center justify-content-center">
                                <div class="ms-2">
                                    <text class="h6 fw-bold ci_green">1212</text>
                                </div>
                            </div>
                            <div
                                class="col-xl-1 col-lg-12 col-md-3 col-12 d-flex align-items-center justify-content-end justify-content-sm-end justify-content-md-end justify-content-lg-end justify-content-xl-end mb-2">
                                <div class="float-md-end">
                                    <a href="#" class="">
                                        <i class="fa fa-trash text-danger fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div> -->
                <!-- Product with variations -->

                <!-- Product without variations -->
              
                
                  @php $total = 0 @endphp
                @if(session('cart'))
                @foreach(session('cart') as $id => $details)
               
                <div class="row gy-3 py-3 border-bottom">
                    <div class="col-xl-5 col-lg-6 col-md-12 col-12">
                        <div class="d-flex">
                      
                      <a href="{{ url('product-detail/'.$id) }}" target="_blank">
                                <img src="{{asset('root/public/uploads/'.$details['images']) }}" class="border rounded me-2" style="width: 80px; height: 80px;">
                            </a>
                             
                       @php $decoded = json_decode($details['details']); @endphp
                            <div class="">
                                <a href="{{ url('product-detail/'.$id) }}" target="_blank" class="d-block p">
                                    @php $myArray = explode(',', @$decoded->names); @endphp
                                     @if(!empty($myArray))
                                         @foreach($myArray as $val)
                                             <span>{{ $val }}</span><br>
                                          @endforeach
                                      @endif
                                    </a>
                                <strong class="small">Estimated Ship Date May 16,
                                    2023</strong>

                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-2 col-lg-2 col-md-3 col-4 text-center d-flex align-items-center justify-content-center">
                        <div class="me-2">
                            <text class="h6 fw-400 ci_green">$ {{ @$decoded->total_price }}</text>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-3 col-4 d-flex align-items-center justify-content-center">
                        <div class="addmore_qty d-flex align-items-center justify-content-center">
                            <input type="button" value="-" class="minus btn_primary btn" onclick="QtyUpdate(<?= $id ?>,0)">
                            <input type="number" id="qty<?= $id ?>" class="input-text cart_qty mx-1" step="1" min="1" onchange="update_to_cart(<?= $id ?>)" name="qty[]" value="{{ $details['quantity'] }}" onkeypress="return isNumber(event)" size="4" placeholder="" inputmode="numeric">
                            <input type="button" value="+" class="plus btn_primary btn" onclick="QtyUpdate(<?= $id ?>,1)">
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-3 col-4 text-center d-flex align-items-center justify-content-center">
                        <div class="ms-2">
                            <text class="h6 fw-bold ci_green">$ {{ @$decoded->total_price  * $details['quantity'] }}</text>
                        </div>
                    </div>
                    <div class="col-xl-1 col-lg-12 col-md-3 col-12 d-flex align-items-center justify-content-end justify-content-sm-end justify-content-md-end justify-content-lg-end justify-content-xl-end mb-2">
                        <div class="float-md-end">
                            <a href="javascript::void(0)" onclick="remove_to_cart(<?= $id ?>)" class="">
                                <i class="fa fa-trash text-danger fs-4"></i>
                            </a>
                        </div>
                    </div>
                </div>

                @endforeach
                @endif
                <!-- Product without variations -->
                <div class="pt-4 mb-4">
                    <div class="container">
                        <div class="row align-items-end justify-content-between gy-3">
                            <div class="col-md-7 col-12">
                                <form>
                                    <div class="form-group">
                                        <label class="form-label">Have coupon?</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control border" name="" placeholder="Coupon code" autocomplete="off" style="background-image: url(&quot;chrome-extension://igkpcodhieompeloncfnbekccinhapdb/images/web_access/vault-input-disabled.svg&quot;) !important; background-repeat: no-repeat !important; background-position: calc(100% - 3px) center !important; background-size: 14px !important;">
                                            <button type="button" class="btn btn_secondary">Apply</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-5 col-12 text-end">
                                <div class="cart_update_btn">
                                    <button type="button" class="btn btn_primary">Update Cart</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- cart -->
    <!-- summary -->
    <div class="col-lg-3">
        <div class="card shadow">
            <div class="card-body">
                <h4 class="card-title pb-3 border-bottom">Cart Total</h4>
            </div>
            <div class="card-body pt-0">
                <div class="d-flex justify-content-between">
                    <p class="mb-2">SubTotal:</p>
                    <p class="mb-2 ci_green">$ {{ @$total }}</p>
                </div>
                <div class="d-flex justify-content-between">
                    <p class="mb-2">Shipping:</p>
                    <p class="mb-2 ci_green">$ 00.00</p>
                </div>
                <div class="d-flex justify-content-between">
                    <p class="mb-2">Shipment:</p>
                    <p class="mb-2 text-end">Shipping options will be updated during checkout.
                        <br>
                        <a href="#" class="ci_green mt-2 d-block">Calculate shipping costs</a>
                    </p>
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <p class="mb-2 fs-5 fw-bold">Total:</p>
                    <p class="mb-2 fw-bold ci_green">$ {{ @$total }}</p>
                </div>

                <div class="mt-3">

                @if(count((array) session('cart'))>0)
                    <a href="{{ url('checkout') }}" class="btn btn_primary w-100 mb-2"> Make Purchase </a>
                @else
                     <button class="btn btn_primary w-100 mb-2" disabled> Make Purchase </button>
                @endif
                    <a href="{{ url('/') }}" class="btn btn_outline_primary w-100 border mt-2"> Back to shop </a>
                </div>
            </div>
        </div>
    </div>
    <!-- summary -->
</div>

