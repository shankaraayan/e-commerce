@extends('Layout.Layout')
@section("title")
Privacy Policy
@endsection
<h2>Privacy Policy</h2>