<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastr@2.1.4/build/toastr.min.css" integrity="sha256-R91pD48xW+oHbpJYGn5xR0Q7tMhH4xOrWn1QqMRINtA=" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{ URL::asset('css/style.css') }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/toastr@2.1.4/build/toastr.min.js" integrity="sha256-Hgwq1OBpJ276HUP9H3VJkSv9ZCGRGQN+JldPJ8pNcUM=" crossorigin="anonymous"></script>
    <script src="{{asset('assets/js/main.js')}}" type="module"></script>
    <title>
        @yield("title")
    </title>
    <!-- Sticky Menu Script -->
    <script>
        $(function() {
            var rk_header = $(".web_mainmenu");
            var rk_topheader = $(".top-header");

            $(window).scroll(function() {
                var scroll = $(window).scrollTop();
                if (scroll >= 50) {
                    rk_topheader.addClass("d-none");
                    rk_header.addClass("sticky_css");
                } else {
                    rk_topheader.removeClass("d-none");
                    rk_header.removeClass("sticky_css");
                }
            });
        });
    </script>
    <!-- Sticky Menu Script -->

    <!-- Login popup Script -->
    <script>
        function showforgotpass() {
            var login_div = document.getElementById("login_sec");
            var forgot_pass_div = document.getElementById("forgot_pass_sec");
            if (login_div.style.display === "block") {
                login_div.style.display = "none";
                forgot_pass_div.style.display = "block";
            } else {
                login_div.style.display = "block";
                forgot_pass_div.style.display = "none";
            }
        }

        function loginclick() {
            var login_div = document.getElementById("login_sec").style.display = "block";
            var forgot_pass_div = document.getElementById("forgot_pass_sec").style.display = "none";
        }
    </script>

    <!-- Login popup Script -->
</head>

<body>

    @include('Layout.header')
    @yield('content')
    @include("Layout.footer")


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <script>
        const swiperE3 = document.querySelector('.marketplace_icon')
        Object.assign(swiperE3, {
            slidesPerView: 2,
            spaceBetween: 10,
            pagination: {
                clickable: false,
            },
            breakpoints: {
                640: {
                    slidesPerView: 2,
                    spaceBetween: 10,
                },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 15,
                },
                1024: {
                    slidesPerView: 4,
                    spaceBetween: 20,
                },
            },
        });
        swiperEl.initialize();
    </script>

    <script>
        const swiperE2 = document.querySelector('.swiper-container22')
        Object.assign(swiperE2, {
            slidesPerView: 1,
            spaceBetween: 10,
            pagination: {
                clickable: false,
            },
            breakpoints: {
                640: {
                    slidesPerView: 2,
                    spaceBetween: 10,
                },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 15,
                },
                1024: {
                    slidesPerView: 4,
                    spaceBetween: 20,
                },
            },
        });
        swiperEl.initialize();
    </script>
    <script>
        const swiperEl = document.querySelector('.swiper-container23')
        Object.assign(swiperEl, {
            slidesPerView: 1,
            spaceBetween: 10,
            pagination: {
                clickable: false,
            },
            breakpoints: {
                640: {
                    slidesPerView: 2,
                    spaceBetween: 10,
                },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 15,
                },
                1024: {
                    slidesPerView: 4,
                    spaceBetween: 20,
                },
            },
        });
        swiperEl.initialize();
    </script>


    <script>
        // count down
        $(document).ready(function() {
            $('.counter-value').each(function() {
                $(this).prop('Counter', 0).animate({
                    Counter: $(this).text()
                }, {
                    duration: 3500,
                    easing: 'swing',
                    step: function(now) {
                        $(this).text(Math.ceil(now));
                    }
                });
            });

            $("#cart_section").click(function() {
                $('#cartcanvas_popup').html("");
                $.ajax({
                    type: "GET",
                    url: "{{ url('/get_all_cart_value') }}",
                    dataType: 'html',
                    success: function(text) {
                        $('#cartcanvas_popup').html(text);
                    }
                })
            })
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-element-bundle.min.js"></script>
</body>

</html>