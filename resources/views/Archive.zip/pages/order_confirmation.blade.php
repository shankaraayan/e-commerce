@extends('../Layout.Layout')

@section('content')
<!--------------- Cart Page HTML Start ------------------------->
<div class="container">
<div class="row g-3 mt-3">
    <!-- cart -->
    <div class="col-lg-9">
        <div class="card shadow">
            <div class="p-3 text-center">
                <h1 class="card-title pb-3 border-bottom text-center">Thank you for the Order</h1>
           
                 <h6>Your Tracking Id is {{ $order->transaction_id }}</h6>
                 <h6>Your Order Id is {{ $order->order_id }}</h6>
               
            </div>
        </div>
    </div>
   
</div>
     
</div>


<!--------------- Cart Page HTML End ------------------------->
@endsection