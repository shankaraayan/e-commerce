@extends('Layout.Layout')
@section("title")
Terms'S condition
@endsection
<h2>Terms & condition</h2>