@extends('Layout.Layout')

@section("title")
Data sheet
@endsection

@section("content")
<h2>Data sheet</h2>
@endsection