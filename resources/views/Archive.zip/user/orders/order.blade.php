@extends('user.layout')

@section('dasboard_content')
<div class="orders_section table-responsive px-0">
        <div class="dash_title text-uppercase border-bottom pb-3 mb-4 h6">Order Details</div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr style="vertical-align: middle;">
                    <td><a href="#">#12345</a></td>
                    <td>May 29, 2023</td>
                    <td>On hold</td>
                    <td><span class="ci_green">$ 1,1922</span> <span class="order_qty p text-muted">for 2 items</span></td>
                    <td>
                        <a href="#" class="btn btn_primary">To Sue</a>
                    </td>
                </tr>
                <tr style="vertical-align: middle;">
                    <td><a href="#">#12345</a></td>
                    <td>May 29, 2023</td>
                    <td>On hold</td>
                    <td><span class="ci_green">$ 1,1922</span> <span class="order_qty p text-muted">for 2 items</span></td>
                    <td>
                        <a href="#" class="btn btn_primary">To Sue</a>
                    </td>
                </tr>
                <tr style="vertical-align: middle;">
                    <td><a href="#">#12345</a></td>
                    <td>May 29, 2023</td>
                    <td>On hold</td>
                    <td><span class="ci_green">$ 1,1922</span> <span class="order_qty p text-muted">for 2 items</span></td>
                    <td>
                        <a href="#" class="btn btn_primary">To Sue</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
@endsection