@extends('../Layout.Layout')

@section("content")
<h2>signle products</h2>
@endsection