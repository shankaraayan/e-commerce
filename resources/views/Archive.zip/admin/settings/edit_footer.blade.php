@extends('admin.layout.header') @section('content')
<div class="content-wrapper transition-all duration-150 ltr:ml-[248px] rtl:mr-[248px]" id="content_wrapper">
    <div class="page-content">
        <div class="transition-all duration-150 container-fluid" id="page_layout">
            <div id="content_layout">
                <!-- BEGIN: Breadcrumb -->
                <div class="mb-5">
                    <ul class="m-0 p-0 list-none">
                        <li class="inline-block relative top-[3px] text-base text-primary-500 font-Inter">
                            <a href="index.html">
                                <iconify-icon icon="heroicons-outline:home"></iconify-icon>
                                <iconify-icon icon="heroicons-outline:chevron-right" class="relative text-slate-500 text-sm rtl:rotate-180"></iconify-icon>
                            </a>
                        </li>
                        <li class="inline-block relative text-sm text-primary-500 font-Inter">
                            Product Manager
                            <iconify-icon icon="heroicons-outline:chevron-right" class="relative top-[3px] text-slate-500 rtl:rotate-180"></iconify-icon>
                        </li>
                        <li class="inline-block relative text-sm text-slate-500 font-Inter dark:text-white">
                            Products
                        </li>
                    </ul>
                </div>
                <!-- END: BreadCrumb -->
                <div class="grid xl:grid-cols-1 grid-cols-1 gap-6">
                    <!-- Basic Inputs -->
                    <div class="card">
                        <div class="card-body flex flex-col p-6">
                            <header class="flex mb-5 items-center border-b border-slate-100 dark:border-slate-700 pb-5 -mx-6 px-6">
                                <!--<div class="flex-1">-->
                                <!--    <div class="card-title text-slate-900 dark:text-white">Add new address</div>-->
                                <!--</div>-->
                            </header>
                            <div class="card-text h-full space-y-4">
                                <form  method="post" action="{{route('admin.settings.footer.update',$address->id)}}" class="grid md:grid-cols-2 w-full gap-4">
                                    @csrf
                                    <div class="input-area mb-4">
                                        <label for="name" class="form-label" required>Warehouse name</label>
                                        <input id="name" value="{{$address->ware_house_name}}" name="warehouse_name" type="text" class="form-control" placeholder="warehouse name" />
                                    </div>
                                    <div class="input-area mb-4">
                                        <label for="name" class="form-label" required>Email</label>
                                        <input id="name" value="{{$address->email}}" name="email" type="text" class="form-control" placeholder="email" />
                                    </div>
                                    <div class="input-area mb-4">
                                        <label for="name" class="form-label" required>Mobile</label>
                                        <input id="name" value="{{$address->mobile}}" name="mobile" type="text" class="form-control" placeholder="mobile" />
                                    </div>
                                    <div class="input-area mb-4">
                                        <label for="name" class="form-label" required>country</label>
                                        <input id="name" value="{{$address->country}}" name="country" type="text" class="form-control" placeholder="country" />
                                    </div>
                                    <div class="input-area mb-4">
                                        <label for="name" class="form-label" required>Pin code</label>
                                        <input id="name" value="{{$address->pincode}}" name="pincode" type="text" class="form-control" placeholder="pincode" />
                                    </div>
                                    <div class="input-area mb-4">
                                        <label for="name" class="form-label" required>Vat ID</label>
                                        <input id="name" value="{{$address->vat}}" name="vat" type="text" class="form-control" placeholder="vat id" />
                                    </div>

                                    <div class="input-area mb-4">
                                        <label for="description" class="form-label" required>Address</label>
                                        <textarea id="description" name="address" rows="3" class="form-control" placeholder="address">
                                            {{$address->address}}
                                        </textarea>
                                    </div>

                                    <div class="input-area mb-4 col-start-1 col-end-12">
                                        <button type="submit" class="btn inline-flex justify-center btn-outline-primary rounded-[25px]">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
