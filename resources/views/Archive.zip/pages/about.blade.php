@extends('Layout.Layout')

@section("title")
About us
@endsection

@section("content")
   <h2>about us</h2>
@endsection