@extends('admin.layout.header')
 
@section('content')
<div class="content-wrapper transition-all duration-150 ltr:ml-[248px] rtl:mr-[248px]" id="content_wrapper">
    <div class="page-content">
      <div class="transition-all duration-150 container-fluid" id="page_layout">
        <div id="content_layout">

          <!-- BEGIN: Breadcrumb -->
          <div class="mb-5">
            <ul class="m-0 p-0 list-none">
              <li class="inline-block relative top-[3px] text-base text-primary-500 font-Inter ">
                <a href="index.html">
                  <iconify-icon icon="heroicons-outline:home"></iconify-icon>
                  <iconify-icon icon="heroicons-outline:chevron-right" class="relative text-slate-500 text-sm rtl:rotate-180"></iconify-icon>
                </a>
              </li>
              <li class="inline-block relative text-sm text-primary-500 font-Inter ">
                Product Manager
                <iconify-icon icon="heroicons-outline:chevron-right" class="relative top-[3px] text-slate-500 rtl:rotate-180"></iconify-icon>
              </li>
              <li class="inline-block relative text-sm text-slate-500 font-Inter dark:text-white">
                Products</li>
            </ul>
          </div>
          <!-- END: BreadCrumb -->


          <div class=" space-y-5">
           
            <div class="card">
              <header class=" card-header noborder">
                <h4 class="card-title">View Address
                </h4>
                <a href="{{route('admin.settings.footer.edit',$address->id)}}"> <button type="button" class="btn btn-primary" style="float:right;"> Edit Address </button></a>
              </header>
              <div class="card-body px-6 pb-6">
                <div class="overflow-x-auto -mx-6 dashcode-data-table">
                  <span class=" col-span-8  hidden"></span>
                  <span class="  col-span-4 hidden"></span>
                  <div class="inline-block min-w-full align-middle">
                    <div class="overflow-hidden p-4 ">
                        <div class="w-full mx-auto p-4 border border-slate-500 grid lg:grid-cols-4 md:grid-cols-3 gap-4 rounded-md">
                            <div class="border border-indigo-500 shadow-sm p-2 rounded-md">
                                <strong>Ware house Name</strong>
                                <p>{{$address->ware_house_name}}</p>
                            </div>
                            <div class="border border-indigo-500  shadow-sm p-2 rounded-md">
                                <strong>Email : </strong>
                                <p>{{$address->email}}</p>
                            </div>
                            <div class="border border-indigo-500 shadow-sm p-2 rounded-md">
                                <strong>Mobile</strong>
                                <p>{{$address->mobile}}</p>
                            </div>
                            <div class="border border-indigo-500 shadow-sm p-2 rounded-md">
                                <strong>Country</strong>
                                <p>{{$address->country}}</p>
                            </div> 
                            <div class="border border-indigo-500 shadow-sm p-2 rounded-md">
                                <strong>Pincode</strong>
                                <p>{{$address->pincode}}</p>
                            </div>
                            <div class="border border-indigo-500 shadow-sm p-2 rounded-md">
                                <strong>Address</strong>
                                <p>{{$address->address}}</p>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  @endsection