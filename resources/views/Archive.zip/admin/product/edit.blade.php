@extends('admin.layout.header')

@section('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style>
  .gaps-6 {
    gap: 6.5rem;
  }

  .text-danger {
    color: red;
  }
</style>

<div class="content-wrapper transition-all duration-150 ltr:ml-[248px] rtl:mr-[248px]" id="content_wrapper">
  <div class="page-content">
    <div class="transition-all duration-150 container-fluid" id="page_layout">
      <div id="content_layout">




        <!-- BEGIN: Breadcrumb -->
        <div class="mb-5">
          <ul class="m-0 p-0 list-none">
            <li class="inline-block relative top-[3px] text-base text-primary-500 font-Inter ">
              <a href="index.html">
                <iconify-icon icon="heroicons-outline:home"></iconify-icon>
                <iconify-icon icon="heroicons-outline:chevron-right" class="relative text-slate-500 text-sm rtl:rotate-180"></iconify-icon>
              </a>
            </li>
            <li class="inline-block relative text-sm text-primary-500 font-Inter ">
              Forms
              <iconify-icon icon="heroicons-outline:chevron-right" class="relative top-[3px] text-slate-500 rtl:rotate-180"></iconify-icon>
            </li>
            <li class="inline-block relative text-sm text-slate-500 font-Inter dark:text-white">
              Attribute</li>
          </ul>
        </div>
        <!-- END: BreadCrumb -->

        <div class="grid xl:grid-cols-1">
          <!-- Basic Inputs -->
          <div class="card">
            <div class="card-body flex flex-col p-6">
              <header class="flex mb-5 items-center border-b border-slate-100 dark:border-slate-700 pb-5 -mx-6 px-6">
                <div class="flex-1">
                  <div class="card-title text-slate-900 dark:text-white">Basic Attribute</div>
                </div>
              </header>
              <form action="{{route('admin.product.update')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="card-text h-full space-y-4">
                  <div class="grid xl:grid-cols-3 grid-cols-1 gap-6">
                    <div class="input-area">
                      <label for="name" class="form-label">Product Type*</label>
                      <select class="form-control" name="type">
                        <option>Select Product Type</option>
                        <option @if($editData->type == 'single') selected @endif value="single">Single Product</option>

                        <option @if($editData->type == 'variable') selected @endif value="variable">Variable Product</option>

                      </select>
                      @if ($errors->has('type'))
                      <span class="text-danger">{{ $errors->first('type') }}</span>
                      @endif
                    </div>
                    <div class="input-area">
                      <label for="name" class="form-label">Product Name*</label>
                      <input id="product_name" name="product_name" type="text" value="{{$editData->product_name}}" class="form-control" placeholder="Product Name">
                      @if ($errors->has('product_name'))
                      <span class="text-danger">{{ $errors->first('product_name') }}</span>
                      @endif
                    </div>
                    
                      <div class="input-area">
                      <label for="name" class="form-label">Select Product Category*</label>
                      <select class="form-control" name="categories">
                        <option>Select Product Category</option>
                        @foreach(categories() as $cat)
                       <option value="{{ $cat->id }}" {{ $cat->categories == $cat->categories ? 'selected' : '' }}>
                          {{ $cat->name }}
                        </option>

                       @endforeach

                      </select>
                      @if ($errors->has('categories'))
                      <span class="text-danger">{{ $errors->first('categories') }}</span>
                      @endif
                    </div>
                    <input type="hidden" value="{{$editData->id}}" name="productId">
                    <div class="input-area">
                      <label for="name" class="form-label">SKU*</label>
                      <input type="text" class="form-control" value="{{$editData->sku}}" name="sku">

                      @if ($errors->has('sku'))
                      <span class="text-danger">{{ $errors->first('sku') }}</span>
                      @endif
                    </div>
                  </div>
                  <div class="input-area">
                    <label for="description" class="form-label">Product Description*</label>
                    <textarea id="product_description" name="product_description" rows="5" class="form-control" placeholder="Type Here">{{$editData->product_description}}</textarea>
                    @if ($errors->has('product_description'))
                    <span class="text-danger">{{ $errors->first('product_description') }}</span>
                    @endif
                  </div>
                  <div class="grid xl:grid-cols-3 grid-cols-1 gap-6">
                    <div class="input-area">
                      <label for="name" class="form-label">Product Price(Regular)*</label>
                      <input id="price" name="price" type="text" value="{{$editData->price}}" class="form-control" placeholder="Price">
                      @if ($errors->has('price'))
                      <span class="text-danger">{{ $errors->first('price') }}</span>
                      @endif
                    </div>
                    <div class="input-area">
                      <label for="name" class="form-label">Offer Price(Offer)*</label>
                      <input id="price" name="offer_price" type="text" value="{{$editData->offer_price}}" class="form-control" placeholder="Price">
                      @if ($errors->has('offer_price'))
                      <span class="text-danger">{{ $errors->first('offer_price') }}</span>
                      @endif
                    </div>
                    <div class="input-area">
                      <label for="name" class="form-label">Sale Price(sale)*</label>
                      <input id="price" name="sale_price" type="text" value="{{$editData->sale_price}}" class="form-control" placeholder="Price">
                      @if ($errors->has('sale_price'))
                      <span class="text-danger">{{ $errors->first('sale_price') }}</span>
                      @endif
                    </div>

                  </div>

                  <div class="grid xl:grid-cols-2 grid-cols-1 gap-6">
                    <div class="input-area">
                      <label for="name" class="form-label">Product Category*</label>
                      <label style="margin-right: 10px;">
                        <input type="checkbox" name="best_selling" value="1" @if($editData->best_selling == 1) checked @endif >
                        BEST SELLING
                        @if ($errors->has('best_selling'))
                        <span class="text-danger">{{ $errors->first('best_selling') }}</span>
                        @endif
                      </label>

                      <label style="margin-right: 10px;">
                        <input type="checkbox" name="featured" value="1" @if($editData->featured == 1) checked @endif>
                        FEATURED
                        @if ($errors->has('featured'))
                        <span class="text-danger">{{ $errors->first('featured') }}</span>
                        @endif
                      </label>

                      <label>
                        <input type="checkbox" name="easy_peak_power" value="1" @if($editData->easy_peak_power == 1) checked @endif>
                        EASY PEAK POWER
                        @if ($errors->has('easy_peak_power'))
                        <span class="text-danger">{{ $errors->first('easy_peak_power') }}</span>
                        @endif
                      </label>

                    </div>

                    <div class="input-area">
                      <label for="name" class="form-label">Select Market Place*</label>
                      <label style="margin-right: 10px;">
                        <input type="checkbox" name="mp_option1" value="1" @if($editData->mp_option1 == 1) checked @endif>
                        Camper Gold
                      </label>

                      <label style="margin-right: 10px;">
                        <input type="checkbox" name="mp_option2" value="1" @if($editData->mp_option2 == 1) checked @endif>
                        Option 2
                      </label>

                      <label>
                        <input type="checkbox" name="mp_option3" value="1" @if($editData->mp_option3 == 1) checked @endif>
                        Option 3
                      </label>
                    </div>
                  </div>

                  <div class="grid xl:grid-cols-2 grid-cols-1 gap-6">
                    <div class="input-area">
                      <label for="name" class="form-label">Product thumbnail Image*</label>
                      <label>
                        <input type="file" name="thumb_image">
                        @if ($errors->has('thumb_image'))
                        <span class="text-danger">{{ $errors->first('thumb_image') }}</span>
                        @endif
                      </label>
                    </div>

                    <div class="input-area">
                      <label for="name" class="form-label">Product Image*</label>
                      <label>
                        <input type="file" name="images[]" multiple>
                        @if ($errors->has('images'))
                        <span class="text-danger">{{ $errors->first('images') }}</span>
                        @endif
                      </label>
                    </div>
                  </div>
                  <div class="grid xl:grid-cols-2 grid-cols-1 gap-6">
                    <div class="input-area mb-5">
                      <label for="select" class="form-label">Status</label>
                      <select id="select" name="attribute_status" class="form-control">
                        <option value="1" class="dark:bg-slate-700">Active</option>
                        <option value="0" class="dark:bg-slate-700">InActive</option>
                      </select>
                    </div>
                    <div class="input-area mb-5">
                      <label for="select" class="form-label">Product Availability</label>
                      <input type="date" name="product_availability" class="form-control">
                    </div>
                  </div>
                  <div class="input-area">
                    <button class="btn inline-flex justify-center btn-dark" style="float:right; margin-top:15px;">Submit</button>
                  </div>
                </div>

              </form>
            </div>
          </div>

          <!-- Formatter Support -->
          <div class="card xl:col-span-2 rounded-md bg-white dark:bg-slate-800 lg:h-full shadow-base">

          </div>
        </div>

      </div>
    </div>
  </div>
</div>
@endsection